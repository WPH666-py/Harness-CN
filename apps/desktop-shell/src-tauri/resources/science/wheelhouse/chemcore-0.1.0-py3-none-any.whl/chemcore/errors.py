"""可预期错误（坏输入）的载体。

CLI 只区分两类异常：

* :class:`ChemError` —— 业务错误，带 ``code`` 和一句人话 ``message``，转成结构化 JSON；
* 其它异常 —— 内部 bug，转成 ``code: "internal_error"``，同样不让 traceback 漏到 stdout。
"""

from __future__ import annotations


class ChemError(Exception):
    """带错误码的输入问题。``extra`` 会并进错误信封（例如 diagnostics）。"""

    def __init__(self, code: str, message: str, **extra):
        super().__init__(message)
        self.code = str(code)
        self.message = str(message)
        self.extra = dict(extra)
