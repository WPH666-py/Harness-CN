"""命令行入口：``python -m chemcore.cli``。

约定（Host 侧 ``runJsonProcess`` 就这么用）：

* 从 stdin 读**一整个** JSON 对象；
* 往 stdout 写**一个** JSON 对象，别的什么都不写；
* 退出码永远是 0 —— 出错靠信封里的 ``ok: false`` 表达，不靠退出码。

之所以坚持退出码 0：Host 拿不到输出时只会报「没有输出（退出码 N）」，
那种提示对用户毫无信息量；结构化错误至少能把原因显示在面板上。
"""

from __future__ import annotations

import json
import math
import sys
import traceback
from typing import Any

from . import version
from .ops import run_payload


def _clean(value: Any) -> Any:
    """把结果收拾成严格 JSON：NaN/Inf → null，元组 → 数组，怪类型 → 字符串。"""
    if isinstance(value, dict):
        return {str(key): _clean(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_clean(item) for item in value]
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if isinstance(value, (str, int, bool)) or value is None:
        return value
    try:
        return str(value)
    except Exception:  # pragma: no cover - 理论上不会走到
        return None


def _write(document: dict) -> None:
    text = json.dumps(_clean(document), ensure_ascii=False)
    sys.stdout.buffer.write(text.encode("utf-8") + b"\n")
    sys.stdout.buffer.flush()


def _read_stdin() -> str:
    try:
        raw = sys.stdin.buffer.read()
    except Exception:
        raw = b""
    return raw.decode("utf-8-sig", "replace").strip()


def main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)

    if any(arg in {"-V", "--version"} for arg in args):
        _write({"ok": True, "op": "version", "result": {"version": version.__version__}})
        return 0

    text = _read_stdin()
    if not text:
        _write(
            {
                "ok": False,
                "op": None,
                "code": "no_input",
                "message": "stdin 是空的：请在标准输入上给一个 JSON 请求对象。",
            }
        )
        return 0

    try:
        payload = json.loads(text)
    except json.JSONDecodeError as exc:
        _write(
            {
                "ok": False,
                "op": None,
                "code": "bad_json",
                "message": f"stdin 不是合法 JSON（第 {exc.lineno} 行第 {exc.colno} 列）：{exc.msg}",
            }
        )
        return 0

    try:
        document = run_payload(payload)
    except Exception as exc:  # 最后一道保险：绝不让 traceback 跑到 stdout
        traceback.print_exc(file=sys.stderr)
        document = {
            "ok": False,
            "op": payload.get("op") if isinstance(payload, dict) else None,
            "code": "internal_error",
            "message": f"{type(exc).__name__}: {exc}",
        }

    _write(document)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
