"""分子描述符、类药性规则、结构警报、Murcko 骨架。

``analyze`` 的所有数字都从这里出，键名和 ``client.js`` 的 ``PropTable`` /
``DrugBlock`` 一一对应 —— 改名字等于让面板显示空白，所以这里只增不改。
"""

from __future__ import annotations

import math
from typing import Any

from rdkit import Chem
from rdkit.Chem import Crippen, Descriptors, FilterCatalog, Lipinski, QED, rdMolDescriptors
from rdkit.Chem.Scaffolds import MurckoScaffold

_FILTER_CATALOGS = ("PAINS", "BRENK")
_MAX_ALERTS = 20

_CATALOG: FilterCatalog.FilterCatalog | None = None


def round_number(value: Any, digits: int) -> float | None:
    """四舍五入到 ``digits`` 位；NaN / inf 一律变 None（JSON 里不能出现 NaN）。"""
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(number):
        return None
    return round(number, digits)


def _heteroatoms(mol: Chem.Mol) -> int:
    return sum(1 for atom in mol.GetAtoms() if atom.GetSymbol() != "C")


def properties(mol: Chem.Mol) -> dict:
    """面板「基础性质」表格读的 16 个键。"""
    stereocenters = Chem.FindMolChiralCenters(mol, includeUnassigned=True)
    return {
        "formula": rdMolDescriptors.CalcMolFormula(mol),
        "mw": round_number(Descriptors.MolWt(mol), 3),
        "exact_mw": round_number(Descriptors.ExactMolWt(mol), 4),
        "logp": round_number(Crippen.MolLogP(mol), 4),
        "tpsa": round_number(rdMolDescriptors.CalcTPSA(mol), 2),
        "hbd": int(Lipinski.NumHDonors(mol)),
        "hba": int(Lipinski.NumHAcceptors(mol)),
        "rotatable_bonds": int(rdMolDescriptors.CalcNumRotatableBonds(mol)),
        "heavy_atoms": int(mol.GetNumHeavyAtoms()),
        "rings": int(rdMolDescriptors.CalcNumRings(mol)),
        "aromatic_rings": int(rdMolDescriptors.CalcNumAromaticRings(mol)),
        "aliphatic_rings": int(rdMolDescriptors.CalcNumAliphaticRings(mol)),
        "heteroatoms": _heteroatoms(mol),
        "formal_charge": int(Chem.GetFormalCharge(mol)),
        "fraction_csp3": round_number(rdMolDescriptors.CalcFractionCSP3(mol), 3),
        "stereocenters": len(stereocenters),
    }


def _rule(rule: str, passed: bool, detail: str) -> dict:
    return {"rule": rule, "passed": bool(passed), "detail": detail}


def lipinski_violations(mol: Chem.Mol) -> int:
    """经典 Lipinski 四条里违反了几条（0 才是「不违反」）。"""
    return int(
        int(Descriptors.MolWt(mol) > 500)
        + int(Crippen.MolLogP(mol) > 5)
        + int(Lipinski.NumHDonors(mol) > 5)
        + int(Lipinski.NumHAcceptors(mol) > 10)
    )


def druglikeness(mol: Chem.Mol) -> dict:
    """类药性面板：QED、规则明细、结构警报、Murcko 骨架。"""
    mw = Descriptors.MolWt(mol)
    logp = Crippen.MolLogP(mol)
    hbd = int(Lipinski.NumHDonors(mol))
    hba = int(Lipinski.NumHAcceptors(mol))
    tpsa = rdMolDescriptors.CalcTPSA(mol)
    rotatable = int(rdMolDescriptors.CalcNumRotatableBonds(mol))

    rules = [
        _rule("分子量 ≤ 500", mw <= 500, f"分子量 {mw:.2f}"),
        _rule("logP ≤ 5", logp <= 5, f"logP {logp:.2f}"),
        _rule("氢键给体 ≤ 5", hbd <= 5, f"HBD {hbd}"),
        _rule("氢键受体 ≤ 10", hba <= 10, f"HBA {hba}"),
        _rule("TPSA ≤ 140（Veber）", tpsa <= 140, f"TPSA {tpsa:.2f}"),
        _rule("可旋转键 ≤ 10（Veber）", rotatable <= 10, f"可旋转键 {rotatable}"),
    ]
    # 只有前四条算「Lipinski 违反」，Veber 那两条是补充提示。
    violations = sum(1 for item in rules[:4] if not item["passed"])
    scaffold, generic = scaffolds(mol)

    return {
        "qed": round_number(QED.qed(mol), 4),
        "molar_refractivity": round_number(Crippen.MolMR(mol), 2),
        "lipinski_violations": int(violations),
        "rules": rules,
        "qed_note": (
            "QED 是 Bickerton 等（2012）的综合类药性打分：0 差、1 理想，"
            "0.67 以上通常算不错的候选。"
        ),
        "structural_alerts": structural_alerts(mol),
        "murcko_scaffold": scaffold,
        "murcko_scaffold_generic": generic,
    }


def scaffolds(mol: Chem.Mol) -> tuple[str, str]:
    """(Murcko 骨架, 泛化骨架)；无环分子返回两个空串（面板显示「无环系」）。"""
    try:
        core = MurckoScaffold.GetScaffoldForMol(mol)
        if core is None or core.GetNumAtoms() == 0:
            return "", ""
        return (
            Chem.MolToSmiles(core),
            Chem.MolToSmiles(MurckoScaffold.MakeScaffoldGeneric(core)),
        )
    except Exception:
        return "", ""


def _catalog() -> FilterCatalog.FilterCatalog:
    """PAINS + BRENK 过滤器，建一次反复用（构造挺贵）。"""
    global _CATALOG
    if _CATALOG is None:
        params = FilterCatalog.FilterCatalogParams()
        for name in _FILTER_CATALOGS:
            params.AddCatalog(getattr(FilterCatalog.FilterCatalogParams.FilterCatalogs, name))
        _CATALOG = FilterCatalog.FilterCatalog(params)
    return _CATALOG


def structural_alerts(mol: Chem.Mol) -> list[dict]:
    """命中 PAINS / BRENK 的结构警报，形如 ``{catalog, description}``。"""
    alerts: list[dict] = []
    try:
        matches = _catalog().GetMatches(mol)
    except Exception:
        return alerts

    seen: set[tuple[str, str]] = set()
    for entry in matches:
        try:
            description = entry.GetDescription()
        except Exception:
            continue
        catalog = "filter"
        try:
            catalog = entry.GetProp("FilterSet") or catalog
        except Exception:
            pass
        key = (catalog, description)
        if key in seen:
            continue
        seen.add(key)
        alerts.append({"catalog": catalog, "description": description})
        if len(alerts) >= _MAX_ALERTS:
            break

    alerts.sort(key=lambda item: (item["catalog"], item["description"]))
    return alerts
