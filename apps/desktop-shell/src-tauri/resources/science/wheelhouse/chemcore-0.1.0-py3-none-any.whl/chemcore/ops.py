"""op 分发：每个操作一个函数，统一返回 ``result`` 字典或抛 :class:`ChemError`。

``run_payload`` 负责外层信封：

* 成功 ``{"ok": true, "op": ..., "result": {...}}``
* 失败 ``{"ok": false, "op": ..., "code": ..., "message": ..., "diagnostics": [...]}``

``check`` 是例外——结构不合法也走成功信封，用 ``result.level == "error"`` 表达，
因为面板要靠 ``result.diagnostics[]`` 说话，而不是弹一句错误。
"""

from __future__ import annotations

from typing import Any, Callable

from rdkit import DataStructs, rdBase
from rdkit.Chem import AllChem, rdMolDescriptors

from . import transform
from .bioseq import parse_bioseq
from .descriptors import druglikeness, properties
from .errors import ChemError
from .smiles import canonical, diagnose, parse

__all__ = ["run_payload", "OPS"]

_MORGAN_RADIUS = 2
_MORGAN_BITS = 2048


# ---------------------------------------------------------------- 小工具


def _as_text(value: Any, field: str = "smiles") -> str:
    text = "" if value is None else str(value).strip()
    if not text:
        raise ChemError("empty_input", f"没有给 {field}：输入是空的。")
    return text


def _as_list(value: Any, field: str = "smiles_list") -> list[str]:
    if value is None:
        raise ChemError("empty_input", f"没有给 {field}。")
    if isinstance(value, str):
        items = [item.strip() for item in value.replace(";", "\n").splitlines()]
    elif isinstance(value, (list, tuple)):
        items = [str(item).strip() for item in value]
    else:
        raise ChemError("bad_request", f"{field} 必须是字符串数组。")
    items = [item for item in items if item]
    if not items:
        raise ChemError("empty_input", f"{field} 里一条都没有。")
    return items


def _fingerprint(mol) -> Any:
    """Morgan/ECFP4 指纹。新版 RDKit 把老的 GetMorganFingerprintAsBitVect 标成
    deprecated，优先用 MorganGenerator，老版本回退。"""
    try:
        generator = AllChem.GetMorganGenerator(radius=_MORGAN_RADIUS, fpSize=_MORGAN_BITS)
        return generator.GetFingerprint(mol)
    except AttributeError:  # pragma: no cover - 老 RDKit
        return AllChem.GetMorganFingerprintAsBitVect(
            mol, _MORGAN_RADIUS, nBits=_MORGAN_BITS
        )


# ---------------------------------------------------------------- 各 op


def op_analyze(payload: dict) -> dict:
    text = _as_text(payload.get("smiles"))
    mol = parse(text)
    return {
        "kind": "analyze",
        "input": text,
        "canonical": canonical(mol),
        "properties": properties(mol),
        "druglikeness": druglikeness(mol),
    }


def op_properties(payload: dict) -> dict:
    """和 analyze 同一套数字，``/chem/status`` 自检用的就是它。"""
    result = op_analyze(payload)
    result["kind"] = "properties"
    return result


def op_check(payload: dict) -> dict:
    text = _as_text(payload.get("smiles"))
    from . import smiles as smiles_module

    try:
        mol = parse(text)
    except ChemError as exc:
        diagnostics = exc.extra.get("diagnostics") or [
            {"level": "error", "message": exc.message, "position": None, "raw": None}
        ]
        first = diagnostics[0]
        position = first.get("position")
        return {
            "kind": "check",
            "input": text,
            "level": "error",
            # 顶层的 position 是 0 基：面板自己会 +1 再显示。
            "position": (position - 1) if isinstance(position, int) else None,
            "formula": None,
            "canonical": None,
            "message": exc.message,
            "diagnostics": diagnostics,
        }

    warnings = smiles_module.diagnose(mol, text)
    level = "warn" if any(item["level"] == "warn" for item in warnings) else "ok"
    return {
        "kind": "check",
        "input": text,
        "level": level,
        "position": None,
        "formula": rdMolDescriptors.CalcMolFormula(mol),
        "canonical": canonical(mol),
        "message": None,
        "diagnostics": warnings,
    }


def op_standardize(payload: dict) -> dict:
    return transform.standardize(payload.get("smiles"))


def op_convert(payload: dict) -> dict:
    return transform.convert(payload.get("value"), payload.get("to"))


def op_substructure(payload: dict) -> dict:
    from rdkit import Chem

    text = _as_text(payload.get("smiles"))
    pattern = _as_text(payload.get("smarts") or payload.get("pattern"), "smarts")
    mol = parse(text)

    query = None
    with rdBase.BlockLogs():
        query = Chem.MolFromSmarts(pattern)
    if query is None:
        raise ChemError(
            "invalid_smarts",
            f"这不是合法的 SMARTS：{pattern}。"
            "常见写法：c1ccccc1（苯环）、[CX3](=O)[OX2H1]（羧酸）、[#6]-[#8]。",
        )
    if query.GetNumAtoms() == 0:
        raise ChemError("invalid_smarts", "SMARTS 里一个原子都没有。")

    matches = [list(match) for match in mol.GetSubstructMatches(query)]
    return {
        "kind": "substructure",
        "input": text,
        "smiles": canonical(mol),
        "smarts": pattern,
        "query_atoms": int(query.GetNumAtoms()),
        "matched": bool(matches),
        "count": len(matches),
        "matches": matches,
        "note": "匹配到的原子序号从 0 开始（RDKit 原生下标）。" if matches else "没有命中。",
    }


def op_similarity(payload: dict) -> dict:
    left_text = _as_text(payload.get("a"), "a")
    right_text = _as_text(payload.get("b"), "b")
    left = parse(left_text, field="a")
    right = parse(right_text, field="b")

    left_fp = _fingerprint(left)
    right_fp = _fingerprint(right)
    score = DataStructs.TanimotoSimilarity(left_fp, right_fp)
    left_bits = int(left_fp.GetNumOnBits())
    right_bits = int(right_fp.GetNumOnBits())
    left_set = set(left_fp.GetOnBits())
    right_set = set(right_fp.GetOnBits())
    shared = len(left_set & right_set)

    return {
        "kind": "similarity",
        "a": canonical(left),
        "b": canonical(right),
        "score": round(float(score), 4),
        "fingerprint": f"Morgan/ECFP4（半径 {_MORGAN_RADIUS}，{_MORGAN_BITS} 位）",
        "metric": "Tanimoto",
        "radius": _MORGAN_RADIUS,
        "nbits": _MORGAN_BITS,
        "bits_a": left_bits,
        "bits_b": right_bits,
        "bits_shared": shared,
        "bits_only_a": left_bits - shared,
        "bits_only_b": right_bits - shared,
        "note": "0 表示毫无共同片段，1 表示指纹完全一致；0.4 以上通常算有相似性。",
    }


def _clean_one(index: int, text: str, *, seen: dict[str, int] | None = None) -> dict:
    """清理一条：成功给 canonical/formula，失败给 reason。``index`` 是 1 基。"""
    row: dict = {"index": index, "input": text}
    try:
        mol = parse(text)
        text_canonical = canonical(mol)
        warnings = diagnose(mol, text)
        row.update(
            {
                "ok": True,
                "canonical": text_canonical,
                "formula": rdMolDescriptors.CalcMolFormula(mol),
                "level": "warn" if warnings else "ok",
                "diagnostics": warnings,
                "reason": None,
            }
        )
        if seen is not None:
            first = seen.get(text_canonical)
            if first is None:
                seen[text_canonical] = index
                row["duplicate_of_index"] = None
            else:
                row["duplicate_of_index"] = first
    except ChemError as exc:
        row.update(
            {
                "ok": False,
                "canonical": None,
                "formula": None,
                "level": "error",
                "diagnostics": exc.extra.get("diagnostics") or [],
                "reason": exc.message,
            }
        )
    return row


def op_batch_clean(payload: dict) -> dict:
    items = _as_list(payload.get("smiles_list"))
    rows = [_clean_one(index + 1, text) for index, text in enumerate(items)]
    ok = sum(1 for row in rows if row["ok"])
    warn = sum(1 for row in rows if row["ok"] and row["level"] == "warn")
    failed_items = [
        {"index": row["index"], "input": row["input"], "reason": row["reason"]}
        for row in rows
        if not row["ok"]
    ]
    return {
        "kind": "batch_clean",
        "total": len(items),
        "ok": ok,
        "warn": warn,
        "failed": len(failed_items),
        "failed_items": failed_items,
        "rows": rows,
        "note": "每条都做了规范化 + 去盐前的合法性检查；重复结构请用「去重」。",
    }


def op_dedupe(payload: dict) -> dict:
    items = _as_list(payload.get("smiles_list"))
    seen: dict[str, int] = {}
    rows: list[dict] = []
    duplicates: list[dict] = []

    for index, text in enumerate(items, start=1):
        row = _clean_one(index, text, seen=seen)
        rows.append(row)
        if row["ok"] and row["duplicate_of_index"] is not None:
            duplicates.append(
                {
                    "smiles": row["input"],
                    "duplicate_of_index": row["duplicate_of_index"],
                    "canonical": row["canonical"],
                }
            )

    unique_rows = [row for row in rows if row["ok"] and row["duplicate_of_index"] is None]
    warn = sum(1 for row in unique_rows if row["level"] == "warn")
    failed_items = [
        {"index": row["index"], "input": row["input"], "reason": row["reason"]}
        for row in rows
        if not row["ok"]
    ]
    return {
        "kind": "dedupe",
        "total": len(items),
        "unique": len(unique_rows),
        "warn": warn,
        "failed": len(failed_items),
        "failed_items": failed_items,
        "duplicates": duplicates,
        "unique_rows": unique_rows,
        "rows": rows,
        "note": "按规范化 SMILES 判重：写法不同但结构相同的，也算同一张图。",
    }


def op_bioseq(payload: dict) -> dict:
    return parse_bioseq(payload.get("value"), payload.get("kind", "auto"))


OPS: dict[str, Callable[[dict], dict]] = {
    "analyze": op_analyze,
    "properties": op_properties,
    "check": op_check,
    "standardize": op_standardize,
    "convert": op_convert,
    "substructure": op_substructure,
    "similarity": op_similarity,
    "batch_clean": op_batch_clean,
    "dedupe": op_dedupe,
    "bioseq": op_bioseq,
}


# ---------------------------------------------------------------- 信封


def run_payload(payload: Any) -> dict:
    """执行一条请求，永远返回一个可直接 json.dumps 的字典。"""
    if not isinstance(payload, dict):
        return {
            "ok": False,
            "op": None,
            "code": "bad_request",
            "message": "请求必须是一个 JSON 对象（形如 {\"op\": \"analyze\", \"smiles\": \"CCO\"}）。",
        }

    op = str(payload.get("op") or "").strip()
    if not op:
        return {
            "ok": False,
            "op": None,
            "code": "bad_request",
            "message": "请求里没有 op 字段，不知道该做什么。",
        }

    handler = OPS.get(op.lower())
    if handler is None:
        return {
            "ok": False,
            "op": op,
            "code": "unknown_op",
            "message": f"不认识的操作：{op}；支持 {', '.join(sorted(OPS))}。",
        }

    try:
        result = handler(payload)
    except ChemError as exc:
        envelope = {"ok": False, "op": op.lower(), "code": exc.code, "message": exc.message}
        diagnostics = exc.extra.get("diagnostics")
        if diagnostics:
            envelope["diagnostics"] = diagnostics
        return envelope
    except Exception as exc:  # 兜底：宁可回结构化错误，也不要 traceback
        return {
            "ok": False,
            "op": op.lower(),
            "code": "internal_error",
            "message": f"{type(exc).__name__}: {exc}",
        }

    return {"ok": True, "op": op.lower(), "result": result}
