"""SMILES 解析、词法自检和人话诊断。

面板上有两个位置口径，别混：

* ``diagnostics[i]["position"]`` 是 **1 基** —— 面板直接印「位置：第 N 个字符」；
* 顶层 ``result["position"]`` 是 **0 基** —— 面板自己 ``+1`` 再印。

同一个问题在两处算出来是同一个数字，所以这里统一用 1 基，只在 ``check`` 的返回值里
减 1 给顶层用（见 ``ops.op_check``）。
"""

from __future__ import annotations

import contextlib
import io
import re
from typing import Any

from rdkit import Chem, rdBase

from .errors import ChemError

# RDKit 的 C++ 日志默认直接写进进程 stderr，Python 的 redirect_stderr 抓不到。
# 转到 Python 侧之后才能把 "SMILES Parse Error: unclosed ring" 变成结构化诊断。
rdBase.LogToPythonStderr()

_ALLOWED_CHARS = frozenset(
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    "abcdefghijklmnopqrstuvwxyz"
    "0123456789"
    "[]()=#$:/\\@+-*.%"
)

_TIMESTAMP = re.compile(r"^\[\d{2}:\d{2}:\d{2}\]\s*")
_RD_POSITION = re.compile(r"around position\s+(\d+)", re.I)
_RD_VALENCE = re.compile(
    r"Explicit valence for atom #\s*(\d+)\s*([A-Za-z]{1,2})[\s,;]*(\d+)", re.I
)


def _problem(
    message: str,
    position: int | None = None,
    *,
    level: str = "error",
    raw: str | None = None,
) -> dict:
    """一条诊断。``position`` 用 1 基字符下标；``None`` 表示不知道具体位置。"""
    return {"level": level, "message": message, "position": position, "raw": raw}


@contextlib.contextmanager
def quiet():
    """临时吞掉 RDKit 写往 Python stderr 的日志（返回被吞掉的文本）。"""
    buffer = io.StringIO()
    with contextlib.redirect_stderr(buffer):
        yield buffer


def _mark_ring(token: str, position: int, open_rings: dict[str, int]) -> None:
    if token in open_rings:
        del open_rings[token]  # 同一编号第二次出现 = 闭合
    else:
        open_rings[token] = position


def scan(text: str) -> list[dict]:
    """只做配对检查（圆括号 / 方括号 / 环闭合）和字符检查，不碰 RDKit。

    先自己扫一遍有两个好处：错误位置精确到字符；而且 RDKit 的报错文案是按它自己的
    内部规则给的，``C1CC`` 这种会被它归到「语法错误」，对用户没有帮助。
    """
    problems: list[dict] = []
    open_rings: dict[str, int] = {}
    parens: list[int] = []
    index, length = 0, len(text)

    while index < length:
        char = text[index]
        position = index + 1

        if char == "[":
            closing = text.find("]", index + 1)
            if closing < 0:
                problems.append(_problem("方括号没有配对：[ 在这个位置打开后没有闭合", position))
                break
            nested = text.find("[", index + 1, closing)
            if nested >= 0:
                problems.append(_problem("方括号没有配对：方括号里又出现了 [", nested + 1))
                break
            index = closing + 1
            continue

        if char == "]":
            problems.append(_problem("方括号没有配对：多了一个 ]", position))
            index += 1
            continue

        if char == "(":
            parens.append(position)
            index += 1
            continue

        if char == ")":
            if parens:
                parens.pop()
            else:
                problems.append(_problem("括号没有配对：多了一个 )", position))
            index += 1
            continue

        if char == "%":
            token = text[index + 1 : index + 3]
            if len(token) != 2 or not token.isdigit():
                problems.append(_problem("% 后面必须跟两位环编号（例如 %10）", position))
                index += 1
                continue
            _mark_ring(token, position, open_rings)
            index += 3
            continue

        if char.isdigit():
            _mark_ring(char, position, open_rings)
            index += 1
            continue

        if char not in _ALLOWED_CHARS:
            problems.append(_problem(f"这个字符不属于 SMILES：{char!r}", position))
        index += 1

    for position in parens:
        problems.append(_problem("括号没有配对：这个 ( 没有闭合", position))
    for token, position in open_rings.items():
        problems.append(
            _problem(f"环闭合标记没有配对：'{token}' 在这个位置打开后没有闭合", position)
        )

    problems.sort(key=lambda item: item["position"] or 0)
    return problems


def _valence_message(raw: str) -> str:
    match = _RD_VALENCE.search(raw)
    if not match:
        return "某个原子的价键数超过了允许值（检查双键、电荷或氢原子数）"
    atom_index, element, valence = match.groups()
    return (
        f"第 {int(atom_index) + 1} 个原子（{element}）的显式价键数是 {valence}，"
        "超过了这个元素允许的上限 —— 检查双键、电荷或氢原子数"
    )


def explain(log_text: str, smiles: str) -> list[dict]:
    """把 RDKit 的英文日志翻成人话，一条日志一条诊断。"""
    lines: list[str] = []
    for raw_line in (log_text or "").splitlines():
        line = _TIMESTAMP.sub("", raw_line).strip()
        if not line:
            continue
        lowered = line.lower()
        if lowered.startswith("smiles parse error:"):
            line = line[len("smiles parse error:") :].strip()
        lines.append(line)

    problems: list[dict] = []
    seen: set[str] = set()

    for raw in lines:
        lowered = raw.lower()
        position = None
        match = _RD_POSITION.search(raw)
        if match:
            position = max(1, min(int(match.group(1)), max(len(smiles), 1)))

        if "check for mistakes around position" in lowered:
            continue  # 和上一条是同一件事，位置已经在上面取到了

        if "unclosed ring" in lowered:
            message = "环闭合标记没有配对：RDKit 找不到与它配对的另一个编号"
        elif "extra open parentheses" in lowered:
            message = "括号没有配对：左括号比右括号多"
        elif "unclosed parentheses" in lowered:
            message = "括号没有配对：左括号没有闭合"
        elif "explicit valence" in lowered:
            message = _valence_message(raw)
        elif "kekulize" in lowered:
            message = (
                "芳香环没法完成 Kekulé 化：芳香环上的原子数或价态不对"
                "（常见于漏写、多写双键或电荷）"
            )
        elif "ring closure" in lowered:
            message = "环闭合有问题：编号重复，或者闭合的位置不对"
        elif "syntax error" in lowered or "invalid character" in lowered:
            message = "语法错误：RDKit 解析到一半就停了，通常是某个符号写错或漏写"
        else:
            message = raw

        if message in seen:
            continue
        seen.add(message)
        problems.append(_problem(message, position, raw=raw))

    if not problems:
        problems.append(_problem("RDKit 认为这段结构不合法，但没有给出具体原因"))
    return problems


def parse(smiles: Any, *, field: str = "smiles") -> Chem.Mol:
    """把 SMILES 解析成 RDKit Mol，失败抛 :class:`ChemError`（带 diagnostics）。"""
    text = "" if smiles is None else str(smiles).strip()
    if not text:
        raise ChemError("empty_smiles", f"没有给 {field}：输入是空的。")

    problems = scan(text)
    if problems:
        raise ChemError("invalid_smiles", problems[0]["message"], diagnostics=problems)

    captured = io.StringIO()
    with contextlib.redirect_stderr(captured):
        try:
            mol = Chem.MolFromSmiles(text)
        except Exception as exc:  # Boost.Python 的参数错误也走这里
            raise ChemError("invalid_smiles", f"RDKit 解析失败：{exc}") from exc

    if mol is None or mol.GetNumAtoms() == 0:
        problems = explain(captured.getvalue(), text)
        raise ChemError("invalid_smiles", problems[0]["message"], diagnostics=problems)

    return mol


def diagnose(mol: Chem.Mol, smiles: str = "") -> list[dict]:
    """能解析、但值得提醒的地方（check 用 warn，不拦人）。"""
    problems: list[dict] = []

    fragments = len(Chem.GetMolFrags(mol))
    if fragments > 1:
        problems.append(
            _problem(
                f"这段 SMILES 含 {fragments} 个片段（盐、溶剂或没拆开的混合物）："
                "性质是整个混合物一起算的，去盐请用「标准化」",
                None,
                level="warn",
            )
        )

    charge = Chem.GetFormalCharge(mol)
    if charge:
        problems.append(
            _problem(
                f"净电荷 {charge:+d}：性质按带电形式计算，做类药性判断前通常先中和",
                None,
                level="warn",
            )
        )

    radicals = sum(atom.GetNumRadicalElectrons() for atom in mol.GetAtoms())
    if radicals:
        problems.append(
            _problem(
                f"有 {radicals} 个未成对电子（自由基）：性质和稳定性都和闭壳层分子不一样",
                None,
                level="warn",
            )
        )

    unassigned = [
        center
        for center, flag in Chem.FindMolChiralCenters(mol, includeUnassigned=True)
        if flag == "?"
    ]
    if unassigned:
        places = "、".join(str(center + 1) for center in unassigned[:5])
        problems.append(
            _problem(
                f"有 {len(unassigned)} 个立体中心没写构型（原子序号 {places}）："
                "现在拿到的是立体异构体的混合物",
                None,
                level="warn",
            )
        )

    return problems


def canonical(mol: Chem.Mol) -> str:
    """RDKit 规范化 SMILES（同一结构永远同一个写法）。"""
    return Chem.MolToSmiles(mol)
