"""版本号单独放一处，避免 __init__ 与 ops 互相 import 成环。"""

__version__ = "0.1.0"
