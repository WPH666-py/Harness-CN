"""standardize / convert：结构规范化与格式转换。

``standardize`` 的顺序按 RDKit 官方 MolStandardize 的推荐来：
Cleanup（官能团规范化）→ FragmentParent（去盐/取最大片段）→ Uncharger（中和）。
每一步都记一条 ``changes``，面板逐条显示「步骤：before → after」。
"""

from __future__ import annotations

from typing import Any, Callable

from rdkit import Chem
from rdkit.Chem import rdMolDescriptors
from rdkit.Chem import inchi as rd_inchi
from rdkit.Chem.MolStandardize import rdMolStandardize

from .errors import ChemError
from .smiles import canonical, parse, quiet

# 目标别名 → (内部键, 面板显示名)。client.js 传的是小写 smiles/inchi/inchikey/formula，
# 顺手也认面板上的中文标签，免得手写请求时踩空。
_TARGETS: dict[str, tuple[str, str]] = {
    "smiles": ("smiles", "SMILES"),
    "smi": ("smiles", "SMILES"),
    "canonical": ("smiles", "SMILES"),
    "inchi": ("inchi", "InChI"),
    "inchikey": ("inchikey", "InChIKey"),
    "inchi key": ("inchikey", "InChIKey"),
    "inchi-key": ("inchikey", "InChIKey"),
    "key": ("inchikey", "InChIKey"),
    "formula": ("formula", "分子式"),
    "分子式": ("formula", "分子式"),
    "chemicalformula": ("formula", "分子式"),
}


def _target(value: Any) -> tuple[str, str]:
    raw = str(value if value is not None else "smiles").strip()
    key = raw.lower()
    found = _TARGETS.get(key) or _TARGETS.get(key.replace(" ", "").replace("_", ""))
    if found is None:
        raise ChemError(
            "unknown_target",
            f"不认识的转换目标：{raw}；支持 SMILES / InChI / InChIKey / 分子式。",
        )
    return found


def _safe(action: Callable[[], Chem.Mol], fallback: Chem.Mol) -> Chem.Mol:
    """跑一步规范化；顺手把 RDKit 的初始化日志吞掉（stderr 会污染面板调试信息）。"""
    try:
        with quiet():
            return action()
    except Exception:
        return fallback


def _take_step(
    changes: list[dict], current: str, work: Chem.Mol, candidate: Chem.Mol, label: str
) -> tuple[list[dict], str, Chem.Mol]:
    """候选结构和当前不一样才记一步，避免 changes 里塞满空动作。"""
    if candidate is None:
        return changes, current, work
    try:
        text = canonical(candidate)
    except Exception:
        return changes, current, work
    if not text or text == current:
        return changes, current, work
    changes.append({"step": label, "before": current, "after": text})
    return changes, text, candidate


def standardize(value: Any) -> dict:
    """去盐、中和、官能团规范化，并说明改了什么。"""
    raw = "" if value is None else str(value).strip()
    mol = parse(raw)

    changes: list[dict] = []
    current = canonical(mol)
    if current != raw:
        changes.append({"step": "规范 SMILES", "before": raw, "after": current})

    work = mol

    cleaned = _safe(lambda: rdMolStandardize.Cleanup(work), work)
    changes, current, work = _take_step(changes, current, work, cleaned, "官能团规范化")

    if len(Chem.GetMolFrags(work)) > 1:
        fragment = _safe(lambda: rdMolStandardize.FragmentParent(work), work)
        changes, current, work = _take_step(changes, current, work, fragment, "去盐（取最大片段）")

    neutral = _safe(lambda: rdMolStandardize.Uncharger().uncharge(work), work)
    changes, current, work = _take_step(changes, current, work, neutral, "中和电荷")

    output = canonical(work)
    if output != current:
        changes.append({"step": "规范 SMILES", "before": current, "after": output})
        current = output

    changed = output != raw
    if not changed:
        note = "输入已经是规范形式：去盐、中和、官能团规范化都没有改动。"
    elif changes:
        steps = "、".join(dict.fromkeys(item["step"] for item in changes))
        note = f"共 {len(changes)} 步改动（{steps}）。"
    else:
        note = "结构有变化。"

    return {
        "kind": "standardize",
        "input": raw,
        "output": output,
        "changed": changed,
        "changes": changes,
        "note": note,
        "formula": rdMolDescriptors.CalcMolFormula(work),
    }


def _inchi_from_mol(mol: Chem.Mol) -> str:
    captured = quiet()
    with captured:
        try:
            text = rd_inchi.MolToInchi(mol)
        except Exception as exc:
            raise ChemError("conversion_failed", f"RDKit 生成 InChI 失败：{exc}") from exc
    if not text:
        raise ChemError(
            "conversion_failed",
            "RDKit 生成不了 InChI：有些结构（多价态、非标准互变异构体）不被 InChI 支持。",
        )
    return text


def _mol_from_inchi(text: str) -> Chem.Mol:
    captured = quiet()
    with captured:
        try:
            mol = rd_inchi.MolFromInchi(text)
        except Exception as exc:
            raise ChemError("invalid_inchi", f"这段 InChI 解析不了：{exc}") from exc
    if mol is None or mol.GetNumAtoms() == 0:
        raise ChemError("invalid_inchi", f"这段 InChI 解析不了：{text[:80]}")
    return mol


def convert(value: Any, to: Any) -> dict:
    """SMILES / InChI / InChIKey / 分子式之间的转换。"""
    text = "" if value is None else str(value).strip()
    if not text:
        raise ChemError("empty_input", "没有给要转换的内容：输入是空的。")

    target, label = _target(to)
    source = "InChI" if text.startswith("InChI=") else "SMILES"
    mol = _mol_from_inchi(text) if source == "InChI" else parse(text)

    if target == "smiles":
        output = canonical(mol)
        note = "RDKit 规范化后的 SMILES：同一结构永远同一个写法。"
    elif target == "inchi":
        output = _inchi_from_mol(mol)
        note = "InChI 由 RDKit 内置的 InChI 库生成，含立体层；同一结构在不同工具里应当得到同一个字符串。"
    elif target == "inchikey":
        text_inchi = _inchi_from_mol(mol)
        try:
            output = rd_inchi.InchiToInchiKey(text_inchi)
        except Exception as exc:
            raise ChemError("conversion_failed", f"算不出 InChIKey：{exc}") from exc
        if not output:
            raise ChemError("conversion_failed", "算不出 InChIKey：InChI 本身没能生成。")
        note = "InChIKey 是 InChI 的定长哈希（27 位），适合做唯一标识。"
    else:
        output = rdMolDescriptors.CalcMolFormula(mol)
        note = "分子式按 RDKit 的元素计数给出；带电结构会带 +/- 号。"

    if not output:
        raise ChemError("conversion_failed", f"RDKit 没能把这段结构转成 {label}。")

    return {
        "kind": "convert",
        "input": text,
        "from": source,
        "to": label,
        "value": output,
        "note": note,
    }
