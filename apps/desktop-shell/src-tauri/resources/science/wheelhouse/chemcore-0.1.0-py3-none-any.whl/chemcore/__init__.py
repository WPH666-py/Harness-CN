"""chemcore —— dsh-chem-ui「化学工作台」的本地 RDKit 后端。

宿主半边（``node_modules/dsh-chem-ui/lib/index.js``）的做法是：

    spawn(python, ['-m', 'chemcore.cli'])  →  stdin 写一个 JSON  →  读 stdout 的一个 JSON

所以这里的入口只有两个约定：

* :func:`run_payload` —— 纯函数，给一个 payload 字典，返回一个结果字典；
* :mod:`chemcore.cli` —— 把 stdin/stdout 接上 :func:`run_payload`。

结果信封（和 client.js 的 ``run()`` 对齐）::

    {"ok": true,  "op": "analyze", "result": {...}}
    {"ok": false, "op": "analyze", "code": "invalid_smiles", "message": "人话原因"}

任何输入都不应该让进程抛 traceback：错误一律走 ``ok: false`` 的信封。
"""

from .ops import run_payload
from .version import __version__

__all__ = ["__version__", "run_payload", "run"]


def run(payload):
    """进程内调用（写测试时用），等价于 ``python -m chemcore.cli`` 走一遍 stdin。"""
    return run_payload(payload)
