"""生物序列：多肽、RNA/DNA、HELM 与 IDT 记法。

面板的「自动」只接受**自带类型信息**的写法（HELM / IDT）。裸字母串必须显式选
多肽 / RNA / DNA —— 这是照 client.js:777-790 的约定来的：猜错类型比报错更糟，
``MKTAYIAK`` 既可能是多肽也可能是随便一串字母。
"""

from __future__ import annotations

import re
from typing import Any

from rdkit import Chem
from rdkit.Chem import Descriptors, rdMolDescriptors

from .descriptors import round_number
from .errors import ChemError
from .smiles import quiet

# ---------------------------------------------------------------- 多肽

_AA1 = set("ACDEFGHIKLMNPQRSTVWY")
_AA3 = {
    "ALA": "A", "ARG": "R", "ASN": "N", "ASP": "D", "CYS": "C",
    "GLN": "Q", "GLU": "E", "GLY": "G", "HIS": "H", "ILE": "I",
    "LEU": "L", "LYS": "K", "MET": "M", "PHE": "F", "PRO": "P",
    "SER": "S", "THR": "T", "TRP": "W", "TYR": "Y", "VAL": "V",
    "SEC": "U", "PYL": "O",
}
_AA3_REVERSE = {one: f"{three[0]}{three[1:].lower()}" for three, one in _AA3.items()}

# ---------------------------------------------------------------- 核苷酸
# 碱基模板：{p}/{q} 是环编号占位符（嘌呤两个环、嘧啶一个环），{B} 是插进糖里的碱基，
# {a} 是核糖环编号。所有环都在单个残基内部闭合，所以编号可以逐残基复用。
_BASES_PURINE = {
    "A": "n{p}cnc{q}c(N)ncnc{q}{p}",
    "G": "n{p}cnc{q}c(=O)[nH]c(N)nc{q}{p}",
}
_BASES_PYRIMIDINE = {
    "C": "n{p}ccc(N)nc{p}=O",
    "U": "n{p}ccc(=O)[nH]c{p}=O",
    "T": "n{p}cc(C)c(=O)[nH]c{p}=O",
}

# 糖模板：开头的 O 是 5'-羟基；结尾的 O 是 3'-羟基。残基之间靠「去掉下一个残基
# 5'-O、补一个磷酸」接成 3'→5' 磷酸二酯键。
_SUGARS = {
    "rna": "OC[C@H]{a}O[C@@H]({B})[C@H](O)[C@@H]{a}O",
    "dna": "OC[C@H]{a}O[C@@H]({B})C[C@@H]{a}O",
    "moe": "OC[C@H]{a}O[C@@H]({B})[C@H](OC)[C@@H]{a}O",
}

_NUCLEOTIDE_KINDS = {
    "rna": ("rna", "RNA"),
    "dna": ("dna", "DNA"),
}


def _base_smiles(base: str) -> str:
    if base in _BASES_PURINE:
        return _BASES_PURINE[base].format(p="1", q="2")
    return _BASES_PYRIMIDINE[base].format(p="1")


def _residue_smiles(base: str, sugar: str) -> str:
    text = _SUGARS[sugar]
    if "{q}" in text:  # pragma: no cover - 模板里没有 {q}
        text = text.replace("{q}", "")
    body = text.replace("{a}", "3").replace("{B}", _base_smiles(base))
    return body


def build_nucleotide_smiles(
    residues: list[tuple[str, str]],
    *,
    five_phosphate: bool = False,
    three_phosphate: bool = False,
) -> str:
    """把 [(碱基, 糖)] 拼成一条 SMILES 链。

    ``residues`` 里的碱基取 A/C/G/U/T，糖取 rna/dna/moe。第一个残基保留 5'-OH，
    其余残基把 5'-O 换成 3'→5' 磷酸二酯键；``five_phosphate``/``three_phosphate``
    给两端补上磷酸单酯。
    """
    if not residues:
        raise ChemError("empty_sequence", "序列里一个残基都没有。")

    parts: list[str] = []
    for index, (base, sugar) in enumerate(residues):
        piece = _residue_smiles(base, sugar)
        if index == 0:
            if five_phosphate:
                piece = "OP(=O)(O)O" + piece[1:]
        else:
            # 上一个残基结尾的 O（3'-羟基）先跟磷酸成酯，再接下一个糖的 C5'。
            piece = "P(=O)(O)O" + piece[1:]
        parts.append(piece)

    text = "".join(parts)
    if three_phosphate:
        text += "P(=O)(O)O"
    return Chem.MolToSmiles(Chem.MolFromSmiles(text)) if _valid(text) else text


def _valid(smiles: str) -> bool:
    with quiet():
        return Chem.MolFromSmiles(smiles) is not None


# ---------------------------------------------------------------- 序列清洗


def _clean_letters(text: str) -> str:
    return re.sub(r"[^A-Za-z]", "", text).upper()


def _peptide_sequence(text: str) -> tuple[str, list[str]]:
    """把多肽输入压成单字母序列（``warnings`` 里记下改了哪些写法）。"""
    warnings: list[str] = []
    body = text.strip()
    if not body:
        raise ChemError("empty_sequence", "序列是空的。")

    # 三字母写法：Met-Lys-Thr / MetLysThr / H2N-MKTAY-OH
    stripped = re.sub(r"^(H2N|H-)|(-OH|NH2)$", "", body, flags=re.I)
    tokens = [token for token in re.split(r"[\s\-.,;:|/]+", stripped) if token]
    if tokens and all(len(token) == 3 and token.upper() in _AA3 for token in tokens):
        letters = "".join(_AA3[token.upper()] for token in tokens)
        warnings.append("输入是三字母氨基酸编码，已换成单字母序列。")
        return letters, warnings

    compact = _clean_letters(stripped)
    if len(compact) % 3 == 0 and len(compact) >= 3:
        chunks = [compact[i : i + 3] for i in range(0, len(compact), 3)]
        if all(chunk in _AA3 for chunk in chunks) and len(compact) > 0:
            # 只有整串都能按三字母切开时才走这条路（避免 AGV 被当成 Ala-Gly-Val）
            if len(compact) > 4:
                warnings.append("按三字母氨基酸编码解析（每 3 个字母一个残基）。")
                return "".join(_AA3[chunk] for chunk in chunks), warnings

    unknown = sorted({letter for letter in compact} - _AA1)
    if unknown:
        raise ChemError(
            "bioseq_invalid",
            f"这些字母不是标准氨基酸的单字母编码：{'、'.join(unknown)}。"
            "如果这是三字母写法，请选「多肽（三字母）」。",
        )
    return compact, warnings


def _nucleotide_residues(text: str, sugar: str) -> tuple[list[tuple[str, str]], list[str]]:
    warnings: list[str] = []
    body = _clean_letters(text)
    if not body:
        raise ChemError("empty_sequence", "序列是空的。")

    residues: list[tuple[str, str]] = []
    for letter in body:
        if letter == "U" and sugar == "dna":
            warnings.append("DNA 序列里出现 U，按 T 处理。")
            residues.append(("T", "dna"))
        elif letter == "T" and sugar == "rna":
            warnings.append("RNA 序列里出现 T，按 U 处理。")
            residues.append(("U", "rna"))
        elif letter in "ACGU" or letter in "ACGT":
            residues.append((letter, sugar))
        else:
            raise ChemError(
                "bioseq_invalid",
                f"碱基只能是 A/C/G/U（DNA 还可以用 T），这里出现了 {letter}。",
            )
    return residues, warnings


# ---------------------------------------------------------------- IDT
_IDT_SIMPLE = re.compile(r"r([ACGU])|([ACGT])|(/[^/]+/)")
_IDT_SUGAR = {
    # /i2OMeX/ 是 2'-O-甲基 RNA，正好对应 moe 模板
    "i2ome": "moe",
}


def _parse_idt(text: str) -> tuple[list[tuple[str, str]], bool, bool, list[str], str]:
    """IDT 记法 → (残基, 5'磷酸, 3'磷酸, warnings, 显示用序列)。"""
    warnings: list[str] = []
    body = text.strip()
    five_phosphate = False
    three_phosphate = False

    if body.startswith("/5Phos/"):
        five_phosphate = True
        body = body[len("/5Phos/") :]
    if body.endswith("/3Phos/"):
        three_phosphate = True
        body = body[: -len("/3Phos/")]

    residues: list[tuple[str, str]] = []
    letters: list[str] = []
    position = 0
    while position < len(body):
        match = _IDT_SIMPLE.match(body, position)
        if not match:
            raise ChemError(
                "bioseq_unsupported",
                f"IDT 记法在位置 {position + 1} 读不下去了：{body[position:position + 12]!r}",
            )
        rna_base, dna_base, modifier = match.groups()
        position = match.end()

        if rna_base:
            residues.append((rna_base, "rna"))
            letters.append(rna_base)
        elif dna_base:
            residues.append((dna_base, "dna"))
            letters.append(dna_base)
        else:
            token = modifier.strip("/").lower()
            if token in _IDT_SUGAR:
                sugar = _IDT_SUGAR[token]
                follow = _IDT_SIMPLE.match(body, position)
                if not follow or not (follow.group(1) or follow.group(2)):
                    raise ChemError(
                        "bioseq_unsupported",
                        f"{modifier} 后面缺少碱基：它只是糖环修饰，要跟一个碱基一起写。",
                    )
                base = follow.group(1) or follow.group(2)
                residues.append((base, sugar))
                letters.append(base)
                position = follow.end()
                warnings.append(f"{modifier} 按 2'-O-甲基核糖处理。")
            else:
                raise ChemError(
                    "bioseq_unsupported",
                    f"暂不支持这个 IDT 修饰：{modifier}。"
                    "现在支持 rN / N / i2OMeN / 5Phos / 3Phos。",
                )

    if not residues:
        raise ChemError("empty_sequence", "IDT 记法里没有读到任何残基。")
    return residues, five_phosphate, three_phosphate, warnings, "".join(letters)


# ---------------------------------------------------------------- HELM


def _helm_class(text: str) -> str:
    match = re.match(r"\s*([A-Za-z]+)\d+\s*\{", text)
    return (match.group(1) or "").upper() if match else ""


def _helm_sequence(text: str) -> str:
    """从 HELM 的 ``{...}`` 里抠出残基字母，纯展示用，抠不到就原样返回。"""
    classes = _helm_class(text)
    match = re.search(r"\{([^}]*)\}", text)
    if not match or not classes:
        return text
    tokens = [token for token in re.split(r"[.\s]+", match.group(1)) if token]
    letters: list[str] = []
    for token in tokens:
        body = re.sub(r"[\[\]()]", "", token)
        if body and body[0].isalpha():
            letters.append(body[0].upper())
    return "".join(letters) if letters else text


# ---------------------------------------------------------------- 总入口


def _summarise(mol: Chem.Mol, *, kind: str, fmt: str, residues: int, sequence: str,
               warnings: list[str]) -> dict:
    return {
        "kind": kind,
        "format": fmt,
        "residues": int(residues),
        "formula": rdMolDescriptors.CalcMolFormula(mol),
        "mw": round_number(Descriptors.MolWt(mol), 3),
        "exact_mw": round_number(Descriptors.ExactMolWt(mol), 4),
        "heavy_atoms": int(mol.GetNumHeavyAtoms()),
        "sequence": sequence,
        "smiles": Chem.MolToSmiles(mol),
        "warnings": warnings,
    }


def parse_bioseq(value: Any, kind: Any = "auto") -> dict:
    """按 ``kind`` 解析生物序列，返回面板要的字段。"""
    text = "" if value is None else str(value).strip()
    if not text:
        raise ChemError("empty_sequence", "没有给序列：输入是空的。")

    requested = str(kind or "auto").strip().lower()
    warnings: list[str] = []

    if requested == "auto":
        classes = _helm_class(text)
        if classes in {"RNA", "DNA", "PEPTIDE", "CHEM"}:
            requested = "helm"
        elif re.search(r"/[0-9A-Za-z]+/", text):
            requested = "idt"
        else:
            raise ChemError(
                "bioseq_ambiguous",
                "「自动」不猜序列类型：裸字母串可能是多肽也可能是核酸。"
                "请明确选 多肽 / 多肽（三字母）/ RNA / DNA，或者贴 HELM / IDT 这种"
                "自带类型信息的写法。",
            )

    if requested == "peptide":
        letters, extra = _peptide_sequence(text)
        warnings.extend(extra)
        with quiet():
            mol = Chem.MolFromSequence(letters)
        if mol is None:
            raise ChemError("bioseq_invalid", f"RDKit 建不出这条多肽：{letters[:60]}")
        return _summarise(
            mol, kind="多肽", fmt="peptide", residues=len(letters),
            sequence=letters, warnings=warnings,
        )

    if requested == "peptide3":
        letters, extra = _peptide_sequence(text)
        warnings.extend(extra)
        sequence3 = "".join(_AA3_REVERSE[letter] for letter in letters)
        with quiet():
            mol = Chem.MolFromSequence(sequence3)
        if mol is None:
            with quiet():
                mol = Chem.MolFromSequence(letters)
        if mol is None:
            raise ChemError("bioseq_invalid", f"RDKit 建不出这条多肽：{sequence3[:60]}")
        return _summarise(
            mol, kind="多肽", fmt="peptide3", residues=len(letters),
            sequence=letters, warnings=warnings,
        )

    if requested in _NUCLEOTIDE_KINDS:
        sugar, label = _NUCLEOTIDE_KINDS[requested]
        residues, extra = _nucleotide_residues(text, sugar)
        warnings.extend(extra)
        smiles = build_nucleotide_smiles(residues)
        with quiet():
            mol = Chem.MolFromSmiles(smiles)
        if mol is None:
            raise ChemError("bioseq_invalid", f"这条 {label} 链建不出结构，检查序列。")
        sequence = "".join(base for base, _ in residues)
        return _summarise(
            mol, kind=label, fmt=requested, residues=len(residues),
            sequence=sequence, warnings=warnings,
        )

    if requested == "helm":
        with quiet():
            mol = Chem.MolFromHELM(text)
        if mol is None:
            raise ChemError(
                "bioseq_invalid",
                "RDKit 解析不了这段 HELM：检查 PEPTIDE1/RNA1 之类的前缀和花括号。"
                "（RDKit 目前不支持 DNA1 记法。）",
            )
        classes = _helm_class(text)
        label = {"RNA": "RNA", "DNA": "DNA", "PEPTIDE": "多肽"}.get(classes, "生物大分子")
        if classes == "DNA":
            warnings.append("RDKit 的 HELM 解析对 DNA1 支持不完整，分子量可能不准。")
        sequence = _helm_sequence(text)
        residues = len(sequence) if sequence and sequence != text else mol.GetNumAtoms()
        return _summarise(
            mol, kind=label, fmt="helm", residues=residues,
            sequence=sequence, warnings=warnings,
        )

    if requested == "idt":
        residues, five, three, extra, sequence = _parse_idt(text)
        warnings.extend(extra)
        smiles = build_nucleotide_smiles(
            residues, five_phosphate=five, three_phosphate=three
        )
        with quiet():
            mol = Chem.MolFromSmiles(smiles)
        if mol is None:
            raise ChemError("bioseq_invalid", "这段 IDT 记法建不出结构，检查修饰写法。")
        sugars = {sugar for _, sugar in residues}
        label = "RNA" if sugars == {"rna"} else "DNA" if sugars == {"dna"} else "核酸"
        return _summarise(
            mol, kind=label, fmt="idt", residues=len(residues),
            sequence=sequence, warnings=warnings,
        )

    raise ChemError(
        "bad_kind",
        f"不认识的序列类型：{requested}；支持 auto / peptide / peptide3 / rna / dna / helm / idt。",
    )
