<p align="center">
  <img src="./docs/hero-banner-v4.jpg" alt="dsh-meme — find, send and learn memes" width="100%" />
</p>

<p align="center"><strong>Memes for DeepSeek Harness: pick an image yourself, or let your AI join in.</strong></p>

<p align="center">
  <a href="https://www.npmjs.com/package/dsh-meme"><img src="https://img.shields.io/npm/v/dsh-meme?style=flat-square" alt="npm version" /></a>
  <a href="./LICENSE"><img src="https://img.shields.io/badge/License-MIT-green?style=flat-square" alt="MIT" /></a>
  <img src="https://img.shields.io/badge/Node-%E2%89%A522.13-blue?style=flat-square" alt="Node ≥ 22.13" />
</p>

<p align="center">
  <a href="./README.md">中文</a> · <strong>English</strong><br />
  <a href="https://yyh-001.github.io/dsh-meme/">Pack showcase</a> ·
  <a href="https://github.com/yyh-001/dsh-meme-packs">Pack marketplace</a> ·
  <a href="https://github.com/yyh-001/dsh-meme/issues/new/choose">Report an issue</a> ·
  <a href="https://qm.qq.com/q/7AD2g70HqS">Community &amp; feedback group</a>
</p>

## Features

- **Click to send**: open 😊 beside the composer, search or filter by pack and mood, then pick an image.
- **Chat with memes**: the AI searches by mood or keyword. Web chats render a text marker as an image (no image-input support needed); QQ / WeChat and other IM chats switch to native image delivery through dsh-im.
- **Learn new images**: upload an image and ask to save it; the AI identifies its category and caption.
- **Manage and share**: enable multiple packs, upload and edit images, import/export ZIPs, and install or update marketplace packs.
- **Ready to use**: includes Big Fat Fish (24 images), with no third-party runtime dependencies; uses Node's built-in SQLite.

## Install

In DSH, open **插件 (Plugins) → 添加插件 (Add plugin)**, enter `dsh-meme`, and install.

Or install into a specific profile:

```bash
dsh plugin --profile web add dsh-meme
```

Requires **Node.js ≥ 22.13.0**. The old package name `dsh-expression` is deprecated; its internal plugin ID is retained for compatibility.

## Get started

| Goal | Action |
| --- | --- |
| Send a meme yourself | Click 😊 beside the composer and pick an image; search, multi-select filters and hover previews are available |
| Ask the AI to send one | Say “send a happy meme” or “find a cat making a heart” |
| Save a new image | Upload it and say “save this image to my meme pack”; automatic recognition requires an image-capable model |
| View a larger image | Click a meme in chat; scroll to zoom, double-click to reset, and press Esc or click the background to close |

In chat: send a meme, and the AI replies with one.

<p align="center">
  <img src="./docs/chat-example.png" alt="Meme exchange: the user teases Big Fat Fish, and the AI replies with a meme" width="80%" />
</p>

![Composer picker with search, pack and mood filters](./docs/quick-picker.png)

## Manage packs

Open **设置 (Settings) → 表情包 (Memes)**:

- **图库 (Packs)**: click a card to manage images. Each switch controls whether the AI can use that pack; several can be enabled. Create, import, export, submit or delete packs; “Update” appears when a newer version is available.
- **发现 (Discover)**: preview marketplace packs and install them directly; Release ZIP installations verify SHA-256.
- **设置 (Settings)**: change the scan directory, toggle proactive memes, and edit the prompt.

![Installed packs with independent enable switches](./docs/panel-library.png)

The default scan directory is `~/.dsh/meme-packs`. Settings are saved in `~/.dsh/dsh-expression.json` and survive upgrades. Install more packs from Discover or import a shared ZIP.

## Behind a restrictive network?

The catalog and preview images live on GitHub, so `raw.githubusercontent.com` / `cdn.jsdelivr.net` often time out in mainland China and Discover reports that the catalog is unavailable. Mirrors are tried automatically:

- **Racing mirrors**: catalog, manifest JSON, release ZIPs and images try the original URL plus `ghfast.top`, `gh-proxy.com`, `ghproxy.net`, `cdn.jsdmirror.com` and `fastly.jsdelivr.net`; the first response wins, and images fall back one candidate at a time.
- **Disk cache**: the last good catalog is stored in `~/.dsh/dsh-meme-catalog-cache.json` and used, with a local-cache note, while the network is down.
- **SHA-256 still enforced**: a mirror only changes the transport; a ZIP that fails its hash is discarded and the next mirror is tried.

Still failing? Click **重试 (Retry)** on Discover, check the current source under **图库目录源 (Catalog source)** in Settings → Memes, or use the dropdown there: **自动 (Automatic)**, **官方源 (Official GitHub)**, **镜像源 (Mirrors, best for mainland China)** or **自定义地址 (Custom URL)**. The same values can be written to `"remoteDirUrl"` in `~/.dsh/dsh-expression.json` (`""`/`auto`, `official`, `mirror`, or a `catalog.json` URL) and take effect immediately. To test a mirror:

```bash
curl -I https://ghfast.top/https://raw.githubusercontent.com/yyh-001/dsh-meme-packs/main/catalog.json
curl -o /dev/null -w '%{http_code}\n' https://cdn.jsdmirror.com/gh/yyh-001/dsh-meme-packs@main/catalog.json
```

## Share your own pack

1. Create a pack in Packs and add images.
2. Click **导出 (Export)** to get a ZIP. Friends can install it with **导入图库 (Import pack)**.
3. To join the marketplace, click **投稿 (Submit)**. The plugin exports the ZIP and opens a prefilled GitHub form; sign in, attach the ZIP, add image sources and license details, then submit for review.

Use the plugin's exported ZIP. GitHub's “Download ZIP” is a source archive, not a pack export. Exporting still requires a separate GitHub submission; listing follows approval.

## Tools and extensions

| Tool | Usage |
| --- | --- |
| `send_meme` | `tag` samples a mood bucket; `query` searches captions, keywords or file names across all enabled packs |
| `learn_meme` | Saves the most recent user image by default; also accepts `attachmentId` or `imageUrl` |

```text
send_meme tag=happy
send_meme query="猫 比心"
learn_meme
```

Mood buckets: `happy` / `angry` / `sad` / `shy` / `confused` / `daily`. The model should copy a candidate's `[表情: caption]` marker verbatim; the frontend renders it only in chat content. If no candidate fits, try other keywords or reply with text.

When the conversation comes from QQ / WeChat / Feishu / WeCom or another IM channel through [dsh-im](https://github.com/xmanrui/dsh-im), the sticker is sent as a native image message: the plugin detects the IM source, `send_meme` returns each candidate's **absolute path**, and the model passes it to dsh-im's `dsh_im_return_file`. IM chats never render `[表情: caption]`, so no marker is written. This delivery rule is injected together with the proactive-meme prompt — **no prior user instruction such as “you may send memes on QQ/WeChat” is needed**. Web chats keep the `[表情: caption]` rendering, and both kinds of conversation can coexist in one profile.

For custom catalogs and pack formats, see the [remote pack specification](./docs/remote-pack-spec.md). [dsh-companion](https://github.com/yyh-001/dsh-companion) also provides QQ image delivery.

Plugin HTTP routes accept loopback hosts only (`localhost` / `127.0.0.1` / `[::1]`); LAN addresses and custom domains are rejected.

Code is licensed under [MIT](./LICENSE). Check each pack separately for image provenance and usage rights.
